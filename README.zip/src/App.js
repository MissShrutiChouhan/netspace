import { useState } from 'react';
import './App.css';
import AddData from './components/AddData';
import ShowData from './components/ShowData';

function App() {
  const [onReload,setOnReload] = useState(false)
  return (
    <div className="App">
     <ShowData/>
     <AddData onReload={onReload} setOnReload={setOnReload}/>
    </div>
  );
}

export default App;
