import axios from "axios";
import React, { useEffect, useState } from "react";

const AddData = ({onReload,setOnReload}) => {
  const [CourtName, setCourtName] = useState("");
  const [CreatedBy, setCreatedBy] = useState();
  const [data,setData] = useState([])

  const handleSubmit = (event) => {
    event.preventDefault();
    let formData = new FormData();
    formData.append("CourtName", CourtName);
    formData.append("CreatedBy", CreatedBy);

    fetch("https://api.lawyerhunt.in/api/Master/AddCourt", {
      method: "POST",
      headers: { Authorization: localStorage.getItem("token") },
      body: formData,
    });
    fetch("https://api.lawyerhunt.in/api/Master/ViewCourt", {
      method: "POST",
      headers: { Authorization: localStorage.getItem("token") },
    });
    setOnReload(true)
    setCourtName("");
    setCreatedBy("");
  };


  return (
    <div>
      <form onSubmit={handleSubmit} style={{ margin: "30px" }}>
        <h2>Add Data</h2>
        CourtName
        <input
          type="text"
          name="courtName"
          value={CourtName}
          onChange={(e) => setCourtName(e.target.value)}
        />
        CreatedBy
        <input
          type="number"
          name="createdBy"
          value={CreatedBy}
          onChange={(e) => setCreatedBy(e.target.value)}
        />
        <button type="submit">submit</button>
      </form>
    </div>
  );
};

export default AddData;
