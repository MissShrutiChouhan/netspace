import React, { useEffect, useState } from "react";
import Table from 'react-bootstrap/Table';

const ShowData = () => {
  const [data, setData] = useState([]);

  const token = 'eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJ1aWQiOiIzNSIsInVzZXJuYW1lIjoia2lyYW55ZHY4ODE1QGdtYWlsLmNvbSIsInBhc3N3b3JkIjoiNzExMGVkYTRkMDllMDYyYWE1ZTRhMzkwYjBhNTcyYWMwZDJjMDIyMCIsIkFQSV9USU1FIjoxNzE3MjI4NzU4fQ.5REEo_7mLurCyb1Z9GySG3THD9lD72DpaH4S6jLDnI4';

  useEffect(() => {
    const fetData = async () => {
      try {
        const response = await fetch(
          "https://api.lawyerhunt.in/api/Master/ViewCourt",
          {
            method: "POST",
            headers: { Authorization: token },
          }
        )
          .then((resp) => resp.json())
          .then((json) => {
            localStorage.setItem('token',token)
            setData(json.result);
          });
      } catch (error) {
        console.log(error);
      }
    };
    fetData();

  }, []);
  return (
    <div>
      <Table striped bordered hover>
        <thead>
          <tr>
            <th>Count Name</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {data.map((item, index) => {
            return (
              <>
                <tr>
                  <td>{item.CourtName}</td>
                  <td>{item.Status}</td>
                </tr>
              </>
            );
          })}
        </tbody>
      </Table>
    </div>
  );
};

export default ShowData;
